package com.example.myapplicationaction0630;

import android.content.Context;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class Ball{

    public ImageView ballimage;
    public RelativeLayout.LayoutParams param;
    //public RelativeLayout.LayoutParams getparam;
    public int oldballx;
    public int oldbally;
    public int ballx;
    public int bally;
    public int touchx;
    public int touchy;
    private Handler bHandler = new Handler();
    private Runnable bmakeview;
    Ball(Context con, int bx, int by, int tx, int ty){
        oldballx=bx+200;
        oldbally=by;
        ballx=oldballx;
        bally=oldbally;
        touchx=tx;
        touchy=ty;
        ballimage=new ImageView(con);
        ballimage.setImageResource(R.drawable.batcut);
        param =  new RelativeLayout.LayoutParams(100, 100);
        param.setMargins(oldballx, oldbally, 0, 0);
        ballimage.setLayoutParams(param);

        bmakeview = new Runnable() {
            public void run() {

                if(oldballx<touchx&&oldbally<touchy){
                    ballx=ballx+(touchx-oldballx)/10;
                    bally=bally+(touchy-oldbally)/10;
                    if(ballx>touchx&&bally>touchy){
                        ballimage.setImageResource(0);
                    }
                }
                else if(oldballx<touchx&&oldbally>touchy){
                    ballx=ballx+(touchx-oldballx)/10;
                    bally=bally-(oldbally-touchy)/10;
                    //	param.setMargins(ballx, bally, 0, 0);
                    //	ballimage.setLayoutParams(param);
                    if(ballx>touchx&&bally<touchy){
                        ballimage.setImageResource(0);
                    }
                }

                else if(oldballx>touchx&&oldbally<touchy){
                    ballx=ballx-(oldballx-touchx)/10;
                    bally=bally+(touchy-oldbally)/10;
                    //	param.setMargins(ballx, bally, 0, 0);
                    //	ballimage.setLayoutParams(param);
                    if(ballx<touchx&&bally>touchy){
                        ballimage.setImageResource(0);
                    }
                }
                else if(oldballx>touchx&&oldbally>touchy){
                    ballx=ballx-(oldballx-touchx)/10;
                    bally=bally-(oldbally-touchy)/10;
                    //	param.setMargins(ballx, bally, 0, 0);
                    //	ballimage.setLayoutParams(param);
                    if(ballx<touchx&&bally<touchy){
                        ballimage.setImageResource(0);
                    }
                }

                else{
                    ballimage.setImageResource(0);
                }
                ballimage.layout(ballx, bally, ballx + ballimage.getWidth(), bally
                        + ballimage.getHeight());
                param.setMargins(ballx, bally, 0, 0);
                ballimage.setLayoutParams(param);
                bHandler.removeCallbacks(bmakeview);
                bHandler.postDelayed(bmakeview, 100);
            }
        };
        bHandler.postDelayed(bmakeview, 100);
    }

}
