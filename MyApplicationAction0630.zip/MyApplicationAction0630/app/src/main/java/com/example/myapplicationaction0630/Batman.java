package com.example.myapplicationaction0630;


import android.app.*;
import android.os.*;
import android.*;
import android.widget.*;
import android.content.res.*;
import android.view.*;
import android.content.*;
import java.util.*;
import android.view.View.*;
import android.media.*;
import android.graphics.*;

public class Batman {


    ImageView back;

    int x;//batman位置情報
    int y;//


    int left;
    int top;
    Resources res;
    RelativeLayout linearLayout;

    // ドラッグ中に移動量を取得するための変数
    private int oldx;
    private int oldy;
    //   com.example.bat_1015.ball ball;
    TextView textx;
    TextView texty;

    TextView textdx;
    TextView textdy;
    ImageView hasami;
    Integer countx;
    Integer county;
    Integer countdx;
    Integer countdy;
    Context con;

    RelativeLayout.LayoutParams paramm;

    ;
    RelativeLayout.LayoutParams monsterparam;
    ;

    public Batman(Context con, RelativeLayout linearLayout,RelativeLayout.LayoutParams param, RelativeLayout.LayoutParams textparam){
        back=new ImageView(con);
        back.setImageResource(R.drawable.bat1);
        View.OnTouchListener ont =new ImageView.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                x = (int) event.getRawX();
                y = (int) event.getRawY();
                // 今回イベントでのView移動先の位置
                left = back.getLeft() + (x - oldx);
                top = back.getTop() + (y - oldy);

                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:

                        back.layout(left, top, left + back.getWidth(), top
                                + back.getHeight());
                        paramm =  new RelativeLayout.LayoutParams(400, 400);
                        paramm.setMargins(left, top, 0, 0);
                        back.setLayoutParams(paramm);
                        countdx=paramm.leftMargin;
                        countdx.toString();
                        countdy=paramm.topMargin;
                        countdy.toString();
                        textdx.setText("Debug:バッドマンX座標　"+countdx);
                        textdy.setText("Debug:バッドマンY座標　"+countdy);


                        break;
                }
                oldx=x;
                oldy=y;
                return true;
            }
        };
        back.setOnTouchListener(ont);
        param =  new RelativeLayout.LayoutParams(400, 400);
        param.setMargins(200, 200, 0, 0);
        back.setLayoutParams(param);
        linearLayout.addView(back);

        countdx=param.leftMargin;
        countdx.toString();
        countdy=param.topMargin;
        countdy.toString();

        textdx = new TextView(con);
        textdx.setText("Debug:バッドマンX座標　"+countdx);
        textdx.setTextSize(10);
        textparam=new RelativeLayout.LayoutParams(700, 150);
        textparam.setMargins(50, 200, 0, 0);
        textdx.setLayoutParams(textparam);
        linearLayout.addView(textdx);

        textdy = new TextView(con);
        textdy.setText("Debug:バッドマンY座標　"+countdy);
        textdy.setTextSize(10);
        textparam=new RelativeLayout.LayoutParams(700, 150);
        textparam.setMargins(50, 300, 0, 0);
        textdy.setLayoutParams(textparam);
        linearLayout.addView(textdy);

        //setContentView(linearLayout);
    }

    //touch to change image
    public boolean onTouchEvent(MotionEvent event) {
        x = (int) event.getRawX();
        y = (int) event.getRawY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                //  ball = new ball(con, countdx, countdy, x, y);//タッチした位置バットマンの位置
                //  hasami = ball.ballimage;
                linearLayout.addView(hasami);
                countx = x;
                textx.setText("Debug:エンブレム手裏剣X座標 " + countx.toString());
                county = y;
                texty.setText("Debug:エンブレム手裏剣Y座標 " + county.toString());
                back.setImageResource(R.drawable.bat2);
                break;
            case MotionEvent.ACTION_UP:
                back.setImageResource(R.drawable.bat1);
                break;
        }
        return onTouchEvent(event);
    }

}