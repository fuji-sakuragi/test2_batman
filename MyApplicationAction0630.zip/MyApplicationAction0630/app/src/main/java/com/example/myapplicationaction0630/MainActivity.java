package com.example.myapplicationaction0630;


import android.app.*;
import android.os.*;
import android.*;
import android.widget.*;
import android.content.res.*;
import android.view.*;
import android.content.*;
import java.util.*;
import android.view.View.*;
import android.media.*;
import android.graphics.*;

public class MainActivity extends Activity
{
    RelativeLayout.LayoutParams param;
    RelativeLayout.LayoutParams monsterparam;
    RelativeLayout.LayoutParams textparam;
    int pointX;
    int pointY;
    int left;
    int top;
    Resources res;
    RelativeLayout linearLayout;

    // ドラッグ中に移動量を取得するための変数
    private int oldx;
    private int oldy;
    int x;
    int y;
    ball ball;
    TextView textx;
    TextView texty;

    TextView textdx;
    TextView textdy;
    ImageView back;
    ImageView hasami;
    Integer countx;
    Integer county;
    Integer countdx;
    Integer countdy;
    Context con;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        con=this;
        linearLayout = new RelativeLayout(this);


        /*
         * Debug用
         * バッドマンが投げたコウモリのエンブレム手裏剣の座標の表示
         *
         * 実際に画面でタッチした位置にコウモリ手裏剣を投げる
         * 画面上にタッチした位置を表示させる
         *
         * 初期化および宣言
         *
         * */
        textx = new TextView(this);
        textx.setText("Debug:エンブレム手裏剣X座標　0");
        textx.setTextSize(10);
        textparam=new RelativeLayout.LayoutParams(700, 150);
        textparam.setMargins(50, 10, 0, 0);
        textx.setLayoutParams(textparam);
        linearLayout.addView(textx);

        texty = new TextView(this);
        textx.setText("Debug:エンブレム手裏剣Y座標　0");
        texty.setTextSize(10);
        textparam=new RelativeLayout.LayoutParams(700, 150);
        textparam.setMargins(50, 100, 0, 0);
        texty.setLayoutParams(textparam);
        linearLayout.addView(texty);

        back=new ImageView(this);
        back.setImageResource(R.drawable.bat1);
        OnTouchListener ont =new ImageView.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                x = (int) event.getRawX();
                y = (int) event.getRawY();
                // 今回イベントでのView移動先の位置
                left = back.getLeft() + (x - oldx);
                top = back.getTop() + (y - oldy);

                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:

                        back.layout(left, top, left + back.getWidth(), top
                                + back.getHeight());
                        //param =  new RelativeLayout.LayoutParams(400, 400);
                        param.setMargins(left, top, 0, 0);
                        back.setLayoutParams(param);
                        countdx=param.leftMargin;
                        countdx.toString();
                        countdy=param.topMargin;
                        countdy.toString();
                        textdx.setText("Debug:バッドマンX座標　"+countdx);
                        textdy.setText("Debug:バッドマンY座標　"+countdy);
                        break;
                }
                oldx=x;
                oldy=y;
                return true;
            }
        };
        back.setOnTouchListener(ont);
        param =  new RelativeLayout.LayoutParams(400, 400);
        param.setMargins(200, 200, 0, 0);
        back.setLayoutParams(param);
        linearLayout.addView(back);

        countdx=param.leftMargin;
        countdx.toString();
        countdy=param.topMargin;
        countdy.toString();

        textdx = new TextView(this);
        textdx.setText("Debug:バッドマンX座標　"+countdx);
        textdx.setTextSize(10);
        textparam=new RelativeLayout.LayoutParams(700, 150);
        textparam.setMargins(50, 200, 0, 0);
        textdx.setLayoutParams(textparam);
        linearLayout.addView(textdx);

        textdy = new TextView(this);
        textdy.setText("Debug:バッドマンY座標　"+countdy);
        textdy.setTextSize(10);
        textparam=new RelativeLayout.LayoutParams(700, 150);
        textparam.setMargins(50, 300, 0, 0);
        textdy.setLayoutParams(textparam);
        linearLayout.addView(textdy);

        setContentView(linearLayout);
    }
    //touch to change image
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        x = (int) event.getRawX();
        y = (int) event.getRawY();
        switch(event.getAction()){
            case MotionEvent.ACTION_DOWN:
                ball = new ball(con,countdx,countdy,x,y);//タッチした位置バットマンの位置
                hasami= ball.ballimage;
                linearLayout.addView(hasami);
                countx = x;
                textx.setText("Debug:エンブレム手裏剣X座標 "+countx.toString());
                county = y;
                texty.setText("Debug:エンブレム手裏剣Y座標 "+county.toString());
                back.setImageResource(R.drawable.bat2);
                break;
            case MotionEvent.ACTION_UP:
                back.setImageResource(R.drawable.bat1);
                break;
        }
        return super.onTouchEvent(event);
    }
}

class ball{
    public ImageView ballimage;
    public RelativeLayout.LayoutParams param;
    //public RelativeLayout.LayoutParams getparam;
    public int oldballx;
    public int oldbally;
    public int ballx;
    public int bally;
    public int touchx;
    public int touchy;
    private Handler bHandler = new Handler();
    private Runnable bmakeview;
    ball(Context con,int bx,int by,int tx,int ty){
        oldballx=bx+200;
        oldbally=by;
        ballx=oldballx;
        bally=oldbally;
        touchx=tx;
        touchy=ty;
        ballimage=new ImageView(con);
        ballimage.setImageResource(R.drawable.batcut);
        param =  new RelativeLayout.LayoutParams(100, 100);
        param.setMargins(oldballx, oldbally, 0, 0);
        ballimage.setLayoutParams(param);

        bmakeview = new Runnable() {
            public void run() {

                if(oldballx<touchx&&oldbally<touchy){
                    ballx=ballx+(touchx-oldballx)/10;
                    bally=bally+(touchy-oldbally)/10;
                    if(ballx>touchx&&bally>touchy){
                        ballimage.setImageResource(0);
                    }
                }
                else if(oldballx<touchx&&oldbally>touchy){
                    ballx=ballx+(touchx-oldballx)/10;
                    bally=bally-(oldbally-touchy)/10;
                    //	param.setMargins(ballx, bally, 0, 0);
                    //	ballimage.setLayoutParams(param);
                    if(ballx>touchx&&bally<touchy){
                        ballimage.setImageResource(0);
                    }
                }

                else if(oldballx>touchx&&oldbally<touchy){
                    ballx=ballx-(oldballx-touchx)/10;
                    bally=bally+(touchy-oldbally)/10;
                    //	param.setMargins(ballx, bally, 0, 0);
                    //	ballimage.setLayoutParams(param);
                    if(ballx<touchx&&bally>touchy){
                        ballimage.setImageResource(0);
                    }
                }
                else if(oldballx>touchx&&oldbally>touchy){
                    ballx=ballx-(oldballx-touchx)/10;
                    bally=bally-(oldbally-touchy)/10;
                    //	param.setMargins(ballx, bally, 0, 0);
                    //	ballimage.setLayoutParams(param);
                    if(ballx<touchx&&bally<touchy){
                        ballimage.setImageResource(0);
                    }
                }

                else{
                    ballimage.setImageResource(0);
                }
                ballimage.layout(ballx, bally, ballx + ballimage.getWidth(), bally
                        + ballimage.getHeight());
                param.setMargins(ballx, bally, 0, 0);
                ballimage.setLayoutParams(param);
                bHandler.removeCallbacks(bmakeview);
                bHandler.postDelayed(bmakeview, 100);
            }
        };
        bHandler.postDelayed(bmakeview, 100);
    }
}





